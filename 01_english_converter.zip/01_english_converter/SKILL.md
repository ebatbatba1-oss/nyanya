---
name: 01-english-converter
description: 케이브덕 설정 영문화 — Cave Duck reusable workflow
---

# 케이브덕 설정 영문화

Convert existing Cave Duck SYSTEM, SECRET, and CHARACTER sections into English while preserving Korean proper nouns. Trigger when user requests English conversion of their established bot settings.

Rules:
- Convert explanatory prose, instructions, descriptions, headings and ordinary vocabulary to natural, concise English. Preserve all facts, logic, chronology, conditions, relationships, and hidden secrets without additions or omissions.
- Keep unique Korean names of characters, organizations, locations, abilities, artifacts, titles and invented in-world terms in Hangul. Ordinary Korean nouns are translated. Preserve placeholders, code, HTML, variable identifiers and formatting verbatim.
- Normalize references to the player/user character (유저, 사용자, PC, player character, you when used as a label) to EXACTLY `{{uesr}}` as requested. Never silently correct to `{{user}}`. Do not replace generic 'user' in technical instruction sentences where it is not a character reference. Preserve quoted dialogue second-person pronouns naturally when conversion would alter meaning.
- Output the complete converted text in original section order (SYSTEM / SECRET / CHARACTER or source order). No summary, no missing lines. If no source text is present, ask for it. If a token is ambiguous as a proper noun, keep it in Korean.
- Maintain distinction between public setting and confidential secret; do not leak SECRET content into public sections.
