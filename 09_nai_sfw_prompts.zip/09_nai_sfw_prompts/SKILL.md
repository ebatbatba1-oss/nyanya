---
name: 09_nai_sfw_prompts
description: Create 14 consistent English-tag image prompts with Korean translations for a character.
---

# NAI SFW illustration prompt creation

## When to use
Use when the user asks for step 9 of the CaveDuck workflow or explicitly asks for this deliverable.

## Required input
Use character, world, system, and prior-step data supplied in the current conversation. Preserve canonical names and established lore. If critical inputs are missing, ask one concise question; otherwise make modest, clearly compatible creative choices.

## Execution rules
Produce exactly 14 prompts per character: ID portrait 1, main face portrait 1, five named upper-body expressions, five named cowboy-shot scenarios, and two named cowboy-shot dates. Date images show the character alone; a viewer hand may appear if direction is unambiguous. Maintain fixed hair/eyes/skin/body traits across prompts. Each prompt: English comma-separated tags followed immediately by Korean tag translation. Preserve the source's seven-part ordering, indoor/outdoor/scenery and time tags, no character names in prompts, consistent weighting, no parentheses, no extraneous commentary. Do not describe invisible details in close crops. For multiple characters, process separately in batches of one or two.

## Source fidelity
The original user-provided step 9 specification is stored verbatim in `references/original_user_spec.md`. Follow its detailed formatting and content constraints except where overridden by the non-explicit adaptation in this skill or by platform safety requirements.

## Output medium (mandatory)
This skill writes TEXT PROMPTS ONLY for use in NovelAI. Never call image generation tools, never render or edit images, and never output images. The deliverable is copy-ready English tag strings and Korean translations, not generated artwork. The category counts are 1+1+5+5+2 = 14.
