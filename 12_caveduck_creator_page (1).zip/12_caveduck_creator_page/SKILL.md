---
name: 12_caveduck_creator_page
description: Plan and build a matching creator guide page with profiles, play tips, commands and scrolling sections.
---

# Caveduck creator guide HTML

## When to use
Use when the user asks for step 12 of the CaveDuck workflow or explicitly asks for this deliverable.

## Required input
Use character, world, system, and prior-step data supplied in the current conversation. Preserve canonical names and established lore. If critical inputs are missing, ask one concise question; otherwise make modest, clearly compatible creative choices.

## Execution rules
Support three stages: STEP 1 creator-page theme briefing matching character-page platform theme but differentiated palette; STEP 2 layout plan only; STEP 3 full HTML in a single code block. Use inline styles, clamp sizing, flex-wrap, no class/style/media query, no vertical scrolling on outer container. Sections: recommended user profile, Gemini recommendation, recommended settings (4–6), relationships (4–6), scenarios (8–10), OOC instructions, user-note tracking, widget explanation based on actual existing widget, command reference based on actual previously created commands, friendly creator note. Use max-height:250px;overflow-y:auto on the five specified recommendation/command sections. Do not invent existing commands or widget fields when not supplied; ask for missing inputs or label proposed additions. Treat required viewport meta as explicit exception to allowed-tag list.

## Source fidelity
The original user-provided step 12 specification is stored verbatim in `references/original_user_spec.md`. Follow its detailed formatting and content constraints except where overridden by the non-explicit adaptation in this skill or by platform safety requirements.


## Adaptive creator-page structure (mandatory)
The creator page must feel like a DISTINCT in-world companion to this specific bot, NOT the same dashboard repeated with a new accent color. Derive the visual structure from the step-11 character page's primary interface and motifs, then reinterpret it as an editor/admin/backstage/guide view. Examples: survival terminal -> operator manual; idol artist page -> fanclub staff console; chat archive -> pinned-message guide; fantasy guild ledger -> quest handbook; academy portal -> student handbook. Preserve recognizable shared identity while changing hierarchy, density, palette, and component treatments.

The source's numbered sections specify REQUIRED CONTENT, not a fixed universal visual skeleton. Every requested item and recommended count must remain present; visually reorder, group, or nest sections if a character-specific reading journey improves usability. Make the user-profile fields feel like the world's native form, recommended situations like missions/prompts/scenarios appropriate to genre, and the command guide like the world-specific control reference. Preserve exact supplied OOC copy where required. Keep the five long recommendation/command sections independently scrollable with max-height:250px;overflow-y:auto as required by the source, but style their wrappers differently according to the theme. No outer-container vertical scroll.

At STEP 1, identify the inherited motif, explain the new creator/admin metaphor, choose a contrasting 3–5 color palette, and describe a DIFFERENT information hierarchy with mapping for every required section. At STEP 2, design the concrete inline-CSS structure and mobile fallback, avoiding a generic pile of identical cards. At STEP 3, render that structure in a single complete HTML code block. The Gemini recommendation and status/command references must stay accurate to supplied material. Do not invent canonical commands, widget fields, image URLs, or functioning controls.

## Quality gate
Silently check that the page is obviously linked to its character page but visually distinct; the content is complete; layout varies from prior bots; no generic repeated-card stack; scroll areas work; no unsupported interactive promises; tags close correctly; inline styles only.

## Narrative conversion and coordinated images
Treat the creator guide as the companion to a character introduction designed to make people want to start playing. Start with the most useful setup choices and a clear low-friction entry point; make world rules, commands, notes, and cautions easy to find. Keep all required sections and counts, but avoid lore dumps, generic boilerplate and visually identical sections. Align the creator page with the character page's world-native theme without duplicating its layout. Where illustrations add clarity, use 0–3 purposeful image slots (e.g. interface banner, symbolic prop, play guide diagram) rather than filler. Do not invent image URLs. If images are used, after the STEP 3 HTML code block output a separate `이미지 제작용 NAI 프롬프트` section with matching slot labels, placement, suggested ratio, copyable English comma-separated NAI tags and Korean translation. TEXT ONLY; never generate images. Keep character appearance and lore consistent with step 11. This user-requested prompt section supersedes the source's one-code-block-only rule when images are used.


## Image identity and HTML placement cross-check (mandatory)
Apply the same one-to-one image-slot manifest used by step 11. For every image in the creator-page HTML, use a unique `IMAGE_XX_URL` placeholder and provide exactly one matching NAI text-only prompt below the HTML. Label each prompt with image ID, **exact section/card placement**, subject/type, narrative or instructional purpose, recommended aspect ratio/crop, copy-ready English tags, and Korean translation. Use creator-page-specific numbering; do not confuse its image IDs with step-11 IDs. If reusing a step-11 image, identify it explicitly as a reused asset rather than changing its identity.

Keep subject types separate: background-only and UI-texture images must use `no humans` and exclude all character physical tags; props and clue images should be object-only; a named NPC must be labeled `NPC: 이름 / 역할` and use that NPC's own appearance, never the main character's tags; a main-character image uses only their canonical identity. Never accidentally blend the appearance of different NPCs. Plan placements at STEP 1, specify HTML slots at STEP 2, and verify exact HTML/prompt count and numbering at STEP 3. If the page needs no images, do not add unnecessary prompts.
