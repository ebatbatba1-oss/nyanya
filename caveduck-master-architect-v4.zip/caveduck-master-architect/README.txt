CaveDuck Master Architect v4
최신 업로드 마크다운 양식 기준. 원본 보존 + 변경금지 표식만 출력에서 제거 + 장르/캐릭터별 항목 자동 확장.
SKILL.md와 references 폴더를 함께 유지하세요.
