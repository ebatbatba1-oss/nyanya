CaveDuck Master Architect v6
시스템·세계관 및 사고법은 v5 유지. 파트 4는 character_profile_v6.md로 교체. 새 프로필은 항목명과 핵심 지침 중심으로 정리한 버전이며 예시 전문은 수록하지 않음.
