CaveDuck Master Architect v5
SKILL.md: 실행 지침
references/user_template_original.md: 최신 봇 양식 원본 무수정
references/ideation_and_writing_principles.md: 사고법 10개 및 핵심 작성 원칙 복구
references/genre_extension_engine.md: 장르 자동 확장 참고
