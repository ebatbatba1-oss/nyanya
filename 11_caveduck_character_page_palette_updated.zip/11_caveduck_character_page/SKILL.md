---
name: 11_caveduck_character_page
description: Plan theme, plan layout, and build inline-style responsive character introduction HTML.
---

# Caveduck character introduction HTML

## When to use
Use when the user asks for step 11 of the CaveDuck workflow or explicitly asks for this deliverable.

## Required input
Use character, world, system, and prior-step data supplied in the current conversation. Preserve canonical names and established lore. If critical inputs are missing, ask one concise question; otherwise make modest, clearly compatible creative choices.

## Execution rules
Support three distinct stages, advancing on request: STEP 1 theme-only briefing with palette and section design; STEP 2 implementation structure only, no HTML; STEP 3 complete single HTML code block. Preserve order: prologue hook, opening scene, character profile, optional system, worldbuilding, locations, NPCs. Use inline styles only, no class/style/media query, flex wrapping and clamp sizing, horizontal scroll for locations and NPC cards, translucent overlays and gradient image transitions. Preserve 800–1000 Korean characters for opening scene where feasible, avoid writing user actions. Source requires viewport meta while also enumerating allowed tags without meta; treat viewport meta as an explicit exception. For images, use only user-provided valid URLs or placeholders, never invent image URLs.

## Source fidelity
The original user-provided step 11 specification is stored verbatim in `references/original_user_spec.md`. Follow its detailed formatting and content constraints except where overridden by the non-explicit adaptation in this skill or by platform safety requirements.


## Adaptive, character-first art direction (mandatory)
Do NOT use a universal page template, repeated card stack, or fixed visual hierarchy across different bots. Analyze genre, era, profession, relationship dynamic, key conflict, narrative hook, target emotion, and distinctive motifs BEFORE choosing a visual language. The supplied source's numbered sections are a CONTENT COVERAGE CHECKLIST, not a mandate that every page must look or flow identically. Include all required information, but express it through different thematic UI modules and allow visually motivated reordering, nesting, combining, and progressive reveal when this does not obscure information. Keep the prologue hook prominent and the story comprehensible.

Choose a primary diegetic interface (e.g. survival terminal, incident report, music-streaming artist profile, private chat archive, academy enrollment record, detective caseboard, fantasy guild ledger, train ticket, newspaper front page, dating-app match) that specifically belongs to the world; never pick one merely because it was used last time. Choose a distinctive secondary motif and an interaction metaphor. Change at least FOUR of these dimensions between successive bots when context is available: section order/hierarchy, visual silhouette, card shape, typography scale, navigation metaphor, image-to-text ratio, background texture, palette, information density, narrative reveal, and decorative device. Never change only colors and names.

Vary the implementation: asymmetrical editorial layouts, full-bleed hero, split screen, dossiers, layered screenshots, horizontal story reels, timeline, noticeboard, ticket stubs, file folders, tab-like visual headers, comic panels, or archival letters, according to genre. Avoid defaulting to a centered rounded-card stack. Inline CSS only; make any faux tabs/buttons purely decorative unless real links are provided. Do not imply unsupported JavaScript interaction.

At STEP 1, explicitly provide (a) world-specific visual thesis, (b) primary/secondary motifs, (c) 3–5 colors, (d) a section-by-section information mapping showing where every required item lives, and (e) at least 3 concrete choices that make this layout different from a generic template. At STEP 2, explain a unique HTML structure and mobile fallback, including how every mandatory section is represented. At STEP 3, implement that exact plan rather than falling back to a generic template. Maintain horizontal scrolling for locations and NPC imagery when those sections exist; use an appropriate visual variant for each. If a location or NPC section has no canonical entries, do not invent established lore; request content or mark proposals as such.

## Quality gate
Before output, silently verify: the design feels native to this character/world; every required content field is represented; no copy-paste visual skeleton from another bot; no invented image URLs; mobile readability; all tags closed; inline styles only; character and user agency preserved. If prior page designs are supplied, actively avoid repeating their most prominent pattern.

## Conversion-first storytelling and image prompt pack (mandatory, latest user preference)
The introduction page is a *reason to start chatting*, not just a character encyclopedia. Prioritize a compelling promise, an unanswered question, an immediate interpersonal tension, and a concrete invitation to play without scripting the user's actions, decisions, feelings, or dialogue. Hook with a world-native artifact (e.g. leaked chat, missing-person notice, encrypted message, ticket, contract), then offer a strong character encounter, reveal only what a prospective player should know, and close on a curiosity gap that can be resolved through conversation. Keep canonical secrets secret. Avoid misleading claims, clickbait unrelated to actual play, or overwhelming users with lore before the hook. Make essential rules, relationship premise, starting situation, and meaningful warnings immediately visible and readable on mobile. Ensure the page's design, copy, and imagery together sell this particular character's distinctive emotional appeal.

Design imagery as a deliberate multi-image narrative when appropriate, not a mandatory single portrait: hero/face, atmospheric location, story clue/prop, supporting NPC, pivotal scene, and world detail are possible roles. Select 2–6 useful images depending on page complexity; no filler or duplicate angles. Match each image to an actual HTML slot and a narrative purpose. Prefer using user-supplied URLs; otherwise use stable clearly marked placeholders such as `IMAGE_01_URL` in `src`, never fake URLs. Include informative alt text and ensure gradient overlays, text contrast, crop and responsive behavior. Avoid embedding images of unrevealed secrets or unconfirmed canonical facts.

**Required output on STEP 3:** first provide ONE complete, copy-ready HTML code block, then below it provide a separate section titled `이미지 제작용 NAI 프롬프트` with one English comma-separated tag prompt per image slot, immediately followed by its Korean translation. These are TEXT PROMPTS ONLY: do not generate images or call image-generation tools. Number the slots `IMAGE_01`, `IMAGE_02`, etc. and label each prompt with its HTML placement, visual purpose, suggested aspect ratio, and matching placeholder. For character images, preserve established hair color/style/length, eyes, skin, body type, species and signature clothing, use consistent identity tags; never put the character's name inside the NAI tag string. For scenery or object-only images use `no humans` as appropriate and don't add character attributes. Include specific composition, focal point, lighting, time, setting, colors, and atmosphere, without irrelevant off-camera details. Use NAI-style English tags, optional conservative `N::tag::` weighting, and Korean translation. Use separate code blocks for each copyable English prompt when practical. If the user provides existing images, retain their URLs and generate optional matching/replacement prompts only if desired.

At STEP 1, include an image storyboard (image roles and placement) and the central conversion hook; at STEP 2 map image slots to inline-HTML layout. At STEP 3, the image prompt pack is an explicit user-requested addition overriding the source's old 'only one HTML code block, no explanation' output restriction. No extraneous explanations beyond the HTML and prompt pack. The page should remain usable even before the user replaces image placeholders.


## Exact image-slot manifest and role-specific prompts (mandatory)
For STEP 3, make image usage traceable **one-to-one** between the HTML and the prompt pack. Every `<img>` in the HTML must have one unique numbered placeholder (`IMAGE_01_URL`, `IMAGE_02_URL`, etc.) and exactly one matching image entry below the HTML. Do not reuse a prompt for different images or create prompts for nonexistent slots. For CSS `background-image`, also inventory every placeholder; preferably use `<img>` when it makes the slot easier to replace. Keep the same numbering in HTML, image manifest, and prompts. If the same image is intentionally reused, state the reuse and reference the original slot rather than implying a new asset.

For **each** image prompt, output a compact labeled block with these fields, in this order:
- `이미지 ID`: IMAGE_XX / exact `IMAGE_XX_URL` placeholder
- `삽입 위치`: precise HTML section and element (e.g. 프롤로그 상단 배너, 프로필 메인 초상, 세계관 배경, Locations 두 번째 카드, NPC 첫 번째 카드)
- `이미지 종류/대상`: main character / named NPC / scenery-only / object-only / group / scene illustration
- `연출 목적`: why this image helps the reader want to interact, without spoilers
- `권장 비율 및 구도`: aspect ratio, framing, subject placement, safe space for HTML text overlay
- `NAI 영어 프롬프트`: standalone comma-separated copy-ready English tag string in a fenced code block
- `한국어 번역`: translation of that exact prompt

**Role-aware construction**:
1. Main-character portrait: use ONLY the canonical main character's appearance; keep fixed hair, eyes, skin, species, signature features, outfit when relevant. Choose close-up/upper-body/full-body framing appropriate to that HTML slot.
2. Named NPC portrait: explicitly identify the NPC in the Korean label (`NPC: 이름 / 역할`), but do not insert the name into the English tag string. Build the prompt from that NPC's **own** canonical appearance and outfit, not the protagonist's. Differentiate NPCs visually by their actual supplied traits; do not invent canonical features or copy the protagonist's identity tags. If NPC appearance is unspecified, mark it as a proposed visual direction outside the tag string, or request details if identity accuracy is essential.
3. Scenery/background-only: use `no humans`, `scenery`, and a world-appropriate location, architecture, weather/time, perspective, depth, lighting, palette, and negative space. Exclude all hair/eye/body/character tags and character actions. Compose for wide banner, full-bleed background, or card crop as needed; make overlay text readable.
4. Object/clue-only: use `no humans`, `still life` or suitable object tags, camera framing, surface/material, lighting, and world-consistent symbolic details. Avoid faces, bodies, and character appearance tags. Do not reveal hidden spoilers.
5. Story/interaction scene: identify the featured character(s) and keep each one's traits separate; show only characters actually requested for that scene. If the HTML shows a solo character, do not add NPCs. If a group scene is necessary, distinguish subjects with position and attire rather than merging their traits.
6. Decorative UI textures: use abstract/background-only tags and keep legible negative space; avoid requesting rendered text in AI images when HTML can render the text crisply.

At STEP 1, create a **slot storyboard table** (ID, exact section, subject, visual role, aspect ratio) for every proposed image; at STEP 2, map each slot to an HTML `src` or background placeholder and describe crop/text-overlay handling; at STEP 3, audit that the number of unique placeholders exactly equals the number of numbered prompts, and that NPCs and background-only images cannot inherit main-character tags. Every slot should have a distinct practical purpose, not filler. If an image is removed during design, remove its prompt and renumber consistently.


## 최우선 케이브덕 영역별 호환성 규칙 (2026-10-08 사용자 제공)
**작업 전 반드시 `references/caveduck_html_css_2026-10-08.md`를 읽고 적용한다.** 기존 기술 지침과 충돌하면 이 문서가 우선한다. HTML은 반드시 대상 영역의 태그·CSS 허용표를 따른다. 플랫폼 업데이트에 따라 달라질 수 있으므로 사용자 제공 테스트 기준이라고 표기한다.

소개란 HTML에서는 `details/summary`, `ul/ol/li`, `small`, `u`, `table`, `h1`~`h6`, `<meta>`를 출력하지 않는다. 이전 스킬의 viewport meta 예외 및 접이식 섹션 권장은 폐기한다. 제목은 div/span 스타일, 목록은 div+기호, 정보 공개는 펼친 구획/스크롤로 대체한다. `<img>`와 CSS background:url()은 허용하며 이미지별 목적·삽입 위치·NAI 프롬프트를 일대일로 매칭한다. 기존 요구한 중요 정보 강조와 대화 유도 구조는 유지한다.

## Originality-first technical expansion (mandatory, newest instruction)
Read `references/originality_techniques.md` before every STEP 1/2/3. External HTML samples are **technical learning references only**, not templates. Never replicate their recognizable design, layout, palettes, distinctive animation sequences, assets, text, or presentation. Generate independently from the user's character/world and perform the similarity audit described in that reference. Keep all existing required sections, workflow, image manifests, and prompts unchanged. Compatibility rules in `references/caveduck_html_css_2026-10-08.md` take priority over any technique; unsupported SVG/animation or class-based name replacement from examples must not be assumed to work.


## Five-color palette art direction (mandatory, latest user instruction)
Before STEP 1, read `references/five_color_palette_system.md`. Design a fresh five-slot palette (background, surface, text/neutral, primary, point) using world-specific hue selection, tinted neutrals, restrained accents, and verified contrast. In STEP 1 explain HEX and functional roles; STEP 2 map colors to inline CSS; STEP 3 audit legibility and point-color restraint. The 60–30–10-derived proportions are guidance, not rigid constraints. Do not reuse reference palettes. Keep the existing originality and platform compatibility requirements in force.
