---
name: 11_caveduck_character_page
description: Plan theme, plan layout, and build inline-style responsive character introduction HTML.
---

# Caveduck character introduction HTML

> **단일 파일 통합본.** 모든 필수 지침과 참고 자료를 이 `SKILL.md` 하나에 수록했다. 별도의 `references/` 파일은 필요하지 않다.
> **우선순위:** 사용자의 최신 명시 요청 > 케이브덕 영역별 호환성(부록 B) > **레퍼런스 분해·독립 설계 프로토콜(아래)** > 독창성(부록 C) > 5색 팔레트(부록 D) > 본문 실행 지침 > 원본 보존 지침(부록 A). 원본 지침은 기록을 위해 보존하며, 충돌하는 과거 규칙은 적용하지 않는다.
> **중복 정리:** 동일한 원칙의 반복 설명은 본문에서 한 번만 유지하고, 원문 보존이 필요한 부록 A는 원문 그대로 수록했다.


## 최상위 실행 규칙 — 레퍼런스 다중 분석 → 독립 디자인 생성 (필수)

**핵심:** 사용자가 제공한 여러 HTML/이미지/템플릿은 완성 디자인을 고르는 메뉴가 아니라 **기술·원리의 사례집**이다. 레퍼런스 1개를 선택해 색만 바꾸거나, 레퍼런스 A의 헤더와 B의 카드를 이어 붙이는 방식은 금지한다. 레퍼런스의 레이아웃 실루엣·색·장식·타이포·고유 상징·문구·이미지·애니메이션 시퀀스를 복제하지 않는다. 고유한 표현을 바꾸지 않고 다른 작품처럼 보이게 하는 얕은 변형도 금지한다.

### 0. 입력 수집 및 분석 단위
- 현재 대화의 모든 사용자 제공 레퍼런스를 확인한다. 참조 파일이 현재 접근 불가능하면 추측하여 분석한 척하지 말고 해당 파일 재첨부를 요청한다. 외부 레퍼런스는 사용자가 명시적으로 제공했거나 접근 가능할 때만 분석한다.
- 각 레퍼런스를 다음 **기능 단위**로만 분해한다: 정보 구조, 가독성, 레이아웃 엔진(flex/grid/position), 이미지 처리, 스크롤/전개, 텍스트 강조, 색채 역할, 반응형, 호환성 위험. 특정 작품의 시각적 아이덴티티는 추출 대상에서 제외한다.
- 레퍼런스별로 **배운 범용 원리 2~4개**, **절대 재현하지 않을 식별 요소 2개 이상**, **케이브덕에서 사용 가능/미확인/불가**를 내부적으로 구분한다. 사용자가 원하면 기술 분석표를 보여준다.
- 참고 자료가 여러 개면 공통 원리와 서로 다른 원리를 모두 추출한다. **여러 개를 제공받았는데 하나만 선택해서 나머지를 무시하지 않는다.** 단, 모든 원리를 결과물에 억지로 집어넣지는 않는다.

### 1. 디자인은 레퍼런스가 아니라 세계관에서 출발
- 캐릭터의 장르, 시대, 공간, 직업, 관계 긴장, 비밀의 공개 범위, 감정선, 유저 행동 목표를 분석한다.
- 그 세계에 실재할 법한 **서사적 매체/물건/상황**을 먼저 발명한다(예: 물건의 사용 흔적, 특정 장소의 기록 체계, 사건 진행 과정). 기존 서비스의 UI나 제공 레퍼런스의 테마 이름을 그대로 출발점으로 삼지 않는다.
- 최소 **3개의 구조적으로 다른 시안**을 내부 생성한다. 서로 **주요 실루엣, 정보 공개 순서, 이미지와 텍스트의 관계, 내비게이션/스크롤 은유** 중 3개 이상이 달라야 한다. 같은 카드 배열에 색만 바꾼 것은 다른 시안이 아니다.
- 3안 중에서 **세계관 적합성 / 새로움 / 모바일 가독성 / 케이브덕 호환성 / 내용 충실도**를 비교하여 가장 강한 1안을 선정한다. 사용자가 선택지를 요청하면 3안을 간단히 보여주고 선택을 받는다.

### 2. 범용 기술을 선택적으로 재조합
- 레퍼런스에서 추출한 기능적 원리를 **최소 2개 이상 서로 다른 기술 계열**에서 활용할 수 있는지 검토한다(예: 이미지 레이어링 + 가로 스크롤, 타이포 계층 + 정보 시각화). 기술을 채택하는 이유를 '예쁘니까'가 아닌 **어떤 정보·감정·행동을 전달하는가**로 설명한다.
- 채택 기술의 실제 배치·비율·도형·시각 흐름·색상·장식은 캐릭터에 맞춰 **처음부터 독립 설계**한다. 참고작의 구역 순서나 시그니처 장식이 그대로 남지 않도록 한다.
- 사용자의 콘텐츠 필수 구역은 **빠짐없이 유지**하되, 시각적 표현은 세계관에 맞게 달라져야 한다. 원본 11단계의 '에브리타임/넷플릭스' 같은 예시는 **과거 기록일 뿐 선택 의무나 재현 지시가 아니다.**
- HTML은 검증된 케이브덕 소개란 제약을 우선한다. 불확실한 효과는 대체 가능한 기본 레이아웃을 설계하고 작동한다고 단정하지 않는다.

### 3. 단계별 강제 출력·이행
- **STEP 1:** 디자인 근거, 독립적인 콘셉트, **선정하지 않은 두 시안과 탈락 이유(각 1줄)**, 채택할 범용 기술 2개 이상과 각 사용 목적, 5색 팔레트, 전체 필수 구역의 정보 배치 계획을 제시한다. 레퍼런스 고유 명칭이나 스타일 이름을 최종 콘셉트명으로 쓰지 않는다.
- **STEP 2:** STEP 1에서 선정한 시안의 HTML 구조, 레이어 관계, 스크롤 방식, 모바일 폴백, 영역별 호환성, 이미지 슬롯을 구체적으로 매핑한다. **STEP 1의 핵심 설계가 달라졌으면 이유를 명시하고 수정**한다.
- **STEP 3:** STEP 2 설계를 그대로 코드로 구현한다. 기존의 이미지 슬롯·NAI 프롬프트 일대일 규칙과 필수 콘텐츠는 유지한다. 완료 후 **내부 검사에서 통과하지 못하면 코드부터 재설계**한다.
- 사용자가 '한 번에 최종 코드'를 요청하면 세 단계의 설계를 **내부적으로 모두 수행**하되 불필요한 기획문을 장황하게 출력하지 않는다.

### 4. 비복제·품질 게이트 (통과 전 출력 금지)
1. **출처 분리:** 최종 페이지를 설명할 때 '레퍼런스 ○○처럼'이 아니라 해당 세계관 내부 논리만으로 설명할 수 있는가?
2. **식별 요소 검사:** 참고작의 독특한 색 조합, 장식, 카드 윤곽, 이미지 구도, 제목 처리, 구역 연결 방식, 애니메이션이 유사하게 남아 있지 않은가?
3. **구조 검사:** 참고작과 **페이지 첫 화면의 실루엣·구역 배치·시선 이동 경로**가 실질적으로 다른가? 단순히 색·글씨만 바뀌었다면 실패.
4. **반복 검사:** 이전에 만든 자신의 다른 캐릭터 페이지와도 같은 카드 스택/히어로/섹션 틀을 무비판적으로 재사용하지 않았는가?
5. **기술 검사:** 범용 기술은 의도적으로 선택했는가? 무리한 효과보다 모바일 가독성·호환성이 우선인가?
6. **콘텐츠 검사:** 기존 필수 항목, 이미지 슬롯과 프롬프트, 5색 역할, 유저의 서사적 선택권을 보존했는가?
- 실패 시 **색만 변경하지 말고 구조·서사 매체·이미지 연출을 재설계**한다. 유사성이 없다고 법적 안전을 보장하거나 외부에서 검증받았다고 주장하지 않는다.

## When to use
Use when the user asks for step 11 of the CaveDuck workflow or explicitly asks for this deliverable.

## Required input
Use character, world, system, and prior-step data supplied in the current conversation. Preserve canonical names and established lore. If critical inputs are missing, ask one concise question; otherwise make modest, clearly compatible creative choices.

## Execution rules
Support three distinct stages, advancing on request: STEP 1 theme-only briefing with palette and section design; STEP 2 implementation structure only, no HTML; STEP 3 complete single HTML code block. Preserve order: prologue hook, opening scene, character profile, optional system, worldbuilding, locations, NPCs. Use inline styles only, no class/style/media query, flex wrapping and clamp sizing, horizontal scroll for locations and NPC cards, translucent overlays and gradient image transitions. Preserve 800–1000 Korean characters for opening scene where feasible, avoid writing user actions. Source requires viewport meta while also enumerating allowed tags without meta; treat viewport meta as an explicit exception. For images, use only user-provided valid URLs or placeholders, never invent image URLs.

## Source fidelity
The original user-provided step 11 specification is stored verbatim in **부록 A — 원본 11단계 지침**. Follow its detailed formatting and content constraints except where overridden by the non-explicit adaptation in this skill or by platform safety requirements.


## Adaptive, character-first art direction (mandatory)
Do NOT use a universal page template, repeated card stack, or fixed visual hierarchy across different bots. Analyze genre, era, profession, relationship dynamic, key conflict, narrative hook, target emotion, and distinctive motifs BEFORE choosing a visual language. The supplied source's numbered sections are a CONTENT COVERAGE CHECKLIST, not a mandate that every page must look or flow identically. Include all required information, but express it through different thematic UI modules and allow visually motivated reordering, nesting, combining, and progressive reveal when this does not obscure information. Keep the prologue hook prominent and the story comprehensible.

Choose a primary diegetic interface (e.g. survival terminal, incident report, music-streaming artist profile, private chat archive, academy enrollment record, detective caseboard, fantasy guild ledger, train ticket, newspaper front page, dating-app match) that specifically belongs to the world; never pick one merely because it was used last time. Choose a distinctive secondary motif and an interaction metaphor. Change at least FOUR of these dimensions between successive bots when context is available: section order/hierarchy, visual silhouette, card shape, typography scale, navigation metaphor, image-to-text ratio, background texture, palette, information density, narrative reveal, and decorative device. Never change only colors and names.

Vary the implementation: asymmetrical editorial layouts, full-bleed hero, split screen, dossiers, layered screenshots, horizontal story reels, timeline, noticeboard, ticket stubs, file folders, tab-like visual headers, comic panels, or archival letters, according to genre. Avoid defaulting to a centered rounded-card stack. Inline CSS only; make any faux tabs/buttons purely decorative unless real links are provided. Do not imply unsupported JavaScript interaction.

At STEP 1, explicitly provide (a) world-specific visual thesis, (b) primary/secondary motifs, (c) 3–5 colors, (d) a section-by-section information mapping showing where every required item lives, and (e) at least 3 concrete choices that make this layout different from a generic template. At STEP 2, explain a unique HTML structure and mobile fallback, including how every mandatory section is represented. At STEP 3, implement that exact plan rather than falling back to a generic template. Maintain horizontal scrolling for locations and NPC imagery when those sections exist; use an appropriate visual variant for each. If a location or NPC section has no canonical entries, do not invent established lore; request content or mark proposals as such.

## Quality gate
Before output, silently verify: the design feels native to this character/world; every required content field is represented; no copy-paste visual skeleton from another bot; no invented image URLs; mobile readability; all tags closed; inline styles only; character and user agency preserved. If prior page designs are supplied, actively avoid repeating their most prominent pattern.

## Conversion-first storytelling and image prompt pack (mandatory, latest user preference)
The introduction page is a *reason to start chatting*, not just a character encyclopedia. Prioritize a compelling promise, an unanswered question, an immediate interpersonal tension, and a concrete invitation to play without scripting the user's actions, decisions, feelings, or dialogue. Hook with a world-native artifact (e.g. leaked chat, missing-person notice, encrypted message, ticket, contract), then offer a strong character encounter, reveal only what a prospective player should know, and close on a curiosity gap that can be resolved through conversation. Keep canonical secrets secret. Avoid misleading claims, clickbait unrelated to actual play, or overwhelming users with lore before the hook. Make essential rules, relationship premise, starting situation, and meaningful warnings immediately visible and readable on mobile. Ensure the page's design, copy, and imagery together sell this particular character's distinctive emotional appeal.

Design imagery as a deliberate multi-image narrative when appropriate, not a mandatory single portrait: hero/face, atmospheric location, story clue/prop, supporting NPC, pivotal scene, and world detail are possible roles. Select 2–6 useful images depending on page complexity; no filler or duplicate angles. Match each image to an actual HTML slot and a narrative purpose. Prefer using user-supplied URLs; otherwise use stable clearly marked placeholders such as `IMAGE_01_URL` in `src`, never fake URLs. Include informative alt text and ensure gradient overlays, text contrast, crop and responsive behavior. Avoid embedding images of unrevealed secrets or unconfirmed canonical facts.

**Required output on STEP 3:** first provide ONE complete, copy-ready HTML code block, then below it provide a separate section titled `이미지 제작용 NAI 프롬프트` with one English comma-separated tag prompt per image slot, immediately followed by its Korean translation. These are TEXT PROMPTS ONLY: do not generate images or call image-generation tools. Number the slots `IMAGE_01`, `IMAGE_02`, etc. and label each prompt with its HTML placement, visual purpose, suggested aspect ratio, and matching placeholder. For character images, preserve established hair color/style/length, eyes, skin, body type, species and signature clothing, use consistent identity tags; never put the character's name inside the NAI tag string. For scenery or object-only images use `no humans` as appropriate and don't add character attributes. Include specific composition, focal point, lighting, time, setting, colors, and atmosphere, without irrelevant off-camera details. Use NAI-style English tags, optional conservative `N::tag::` weighting, and Korean translation. Use separate code blocks for each copyable English prompt when practical. If the user provides existing images, retain their URLs and generate optional matching/replacement prompts only if desired.

At STEP 1, include an image storyboard (image roles and placement) and the central conversion hook; at STEP 2 map image slots to inline-HTML layout. At STEP 3, the image prompt pack is an explicit user-requested addition overriding the source's old 'only one HTML code block, no explanation' output restriction. No extraneous explanations beyond the HTML and prompt pack. The page should remain usable even before the user replaces image placeholders.


## Exact image-slot manifest and role-specific prompts (mandatory)
For STEP 3, make image usage traceable **one-to-one** between the HTML and the prompt pack. Every `<img>` in the HTML must have one unique numbered placeholder (`IMAGE_01_URL`, `IMAGE_02_URL`, etc.) and exactly one matching image entry below the HTML. Do not reuse a prompt for different images or create prompts for nonexistent slots. For CSS `background-image`, also inventory every placeholder; preferably use `<img>` when it makes the slot easier to replace. Keep the same numbering in HTML, image manifest, and prompts. If the same image is intentionally reused, state the reuse and reference the original slot rather than implying a new asset.

For **each** image prompt, output a compact labeled block with these fields, in this order:
- `이미지 ID`: IMAGE_XX / exact `IMAGE_XX_URL` placeholder
- `삽입 위치`: precise HTML section and element (e.g. 프롤로그 상단 배너, 프로필 메인 초상, 세계관 배경, Locations 두 번째 카드, NPC 첫 번째 카드)
- `이미지 종류/대상`: main character / named NPC / scenery-only / object-only / group / scene illustration
- `연출 목적`: why this image helps the reader want to interact, without spoilers
- `권장 비율 및 구도`: aspect ratio, framing, subject placement, safe space for HTML text overlay
- `NAI 영어 프롬프트`: standalone comma-separated copy-ready English tag string in a fenced code block
- `한국어 번역`: translation of that exact prompt

**Role-aware construction**:
1. Main-character portrait: use ONLY the canonical main character's appearance; keep fixed hair, eyes, skin, species, signature features, outfit when relevant. Choose close-up/upper-body/full-body framing appropriate to that HTML slot.
2. Named NPC portrait: explicitly identify the NPC in the Korean label (`NPC: 이름 / 역할`), but do not insert the name into the English tag string. Build the prompt from that NPC's **own** canonical appearance and outfit, not the protagonist's. Differentiate NPCs visually by their actual supplied traits; do not invent canonical features or copy the protagonist's identity tags. If NPC appearance is unspecified, mark it as a proposed visual direction outside the tag string, or request details if identity accuracy is essential.
3. Scenery/background-only: use `no humans`, `scenery`, and a world-appropriate location, architecture, weather/time, perspective, depth, lighting, palette, and negative space. Exclude all hair/eye/body/character tags and character actions. Compose for wide banner, full-bleed background, or card crop as needed; make overlay text readable.
4. Object/clue-only: use `no humans`, `still life` or suitable object tags, camera framing, surface/material, lighting, and world-consistent symbolic details. Avoid faces, bodies, and character appearance tags. Do not reveal hidden spoilers.
5. Story/interaction scene: identify the featured character(s) and keep each one's traits separate; show only characters actually requested for that scene. If the HTML shows a solo character, do not add NPCs. If a group scene is necessary, distinguish subjects with position and attire rather than merging their traits.
6. Decorative UI textures: use abstract/background-only tags and keep legible negative space; avoid requesting rendered text in AI images when HTML can render the text crisply.

At STEP 1, create a **slot storyboard table** (ID, exact section, subject, visual role, aspect ratio) for every proposed image; at STEP 2, map each slot to an HTML `src` or background placeholder and describe crop/text-overlay handling; at STEP 3, audit that the number of unique placeholders exactly equals the number of numbered prompts, and that NPCs and background-only images cannot inherit main-character tags. Every slot should have a distinct practical purpose, not filler. If an image is removed during design, remove its prompt and renumber consistently.


## 최우선 케이브덕 영역별 호환성 규칙 (2026-10-08 사용자 제공)
**작업 전 반드시 **부록 B — 케이브덕 영역별 호환성**를 읽고 적용한다.** 기존 기술 지침과 충돌하면 이 문서가 우선한다. HTML은 반드시 대상 영역의 태그·CSS 허용표를 따른다. 플랫폼 업데이트에 따라 달라질 수 있으므로 사용자 제공 테스트 기준이라고 표기한다.

소개란 HTML에서는 `details/summary`, `ul/ol/li`, `small`, `u`, `table`, `h1`~`h6`, `<meta>`를 출력하지 않는다. 이전 스킬의 viewport meta 예외 및 접이식 섹션 권장은 폐기한다. 제목은 div/span 스타일, 목록은 div+기호, 정보 공개는 펼친 구획/스크롤로 대체한다. `<img>`와 CSS background:url()은 허용하며 이미지별 목적·삽입 위치·NAI 프롬프트를 일대일로 매칭한다. 기존 요구한 중요 정보 강조와 대화 유도 구조는 유지한다.

## Originality-first technical expansion (mandatory, newest instruction)
Read **부록 C — 독창성 및 HTML 구현 기술** before every STEP 1/2/3. External HTML samples are **technical learning references only**, not templates. Never replicate their recognizable design, layout, palettes, distinctive animation sequences, assets, text, or presentation. Generate independently from the user's character/world and perform the similarity audit described in that reference. Keep all existing required sections, workflow, image manifests, and prompts unchanged. Compatibility rules in **부록 B — 케이브덕 영역별 호환성** take priority over any technique; unsupported SVG/animation or class-based name replacement from examples must not be assumed to work.


## Five-color palette art direction (mandatory, latest user instruction)
Before STEP 1, read **부록 D — 5색 팔레트 설계**. Design a fresh five-slot palette (background, surface, text/neutral, primary, point) using world-specific hue selection, tinted neutrals, restrained accents, and verified contrast. In STEP 1 explain HEX and functional roles; STEP 2 map colors to inline CSS; STEP 3 audit legibility and point-color restraint. The 60–30–10-derived proportions are guidance, not rigid constraints. Do not reuse reference palettes. Keep the existing originality and platform compatibility requirements in force.


---

# 부록 A — 원본 11단계 지침

11단계[STEP 1: 캐릭터 분석 및 테마/디자인 설정]
당신은 캐릭터의 설정과 세계관을 깊이 이해하고 시각적으로 완벽하게 구현하는 최고 수준의 UI/UX 디자이너입니다. 
아래 제공될 [캐릭터 및 세계관 정보]를 분석하여, 컨셉에 완벽하게 맞는 플랫폼/UI 테마를 기획하십시오.

[ 디자인 설정 방향 ]
- 대학생 배경 → '에브리타임' 스타일 커뮤니티 테마
- 가수/아이돌 배경 → '엠넷/멜론' 등 음악 플랫폼 테마
- 인플루언서 배경 → '유튜브' 또는 '인스타그램' 테마
- 오타쿠/서브컬처 → '트위터' 테마
- 데이팅/만남 → '틴더' 등 데이팅 어플 테마
- 시골/일상 → '마을회관' 레트로 게시판 테마
- 서바이벌/연애프로 → '넷플릭스' 테마
- 기타 세계관에 가장 몰입할 수 있는 최적의 UI 테마 도출

[ 페이지 구역별 디자인 기획 ]
본 페이지는 다음과 같은 구역으로 구성됩니다. 각 구역별로 전체 테마에 어울리는 구체적인 디자인 연출(배경 스타일, 텍스처, 테두리, 텍스트 효과 등)도 함께 기획해 주세요.
0. 프롤로그 훅 (테마 맞춤형 인트로: 에타 게시글, 인스타 피드/댓글, 매칭앱 대화, 넷플릭스 소개 등 흥미 자극 요소)
1. 도입부 (상단 이미지 + 하단 그라데이션 텍스트)
2. 캐릭터 프로필 (메인 캐릭터 카드)
3. 캐릭터 시스템 (해당 시)
4. 세계관 (Worldbuilding)
5. 핵심 구역 (Locations, 반투명 텍스트 박스 + 꽉 찬 이미지 좌우 스크롤 카드)
6. NPC (반투명 텍스트 박스 + 꽉 찬 이미지 좌우 스크롤 카드)

[ 지시 사항 ]
위 기준과 구역 구조를 참고하여, 아래 캐릭터 정보에 맞춘 '적용할 테마 이름', '핵심 색상 팔레트(3~5가지)', '전반적인 시각적 분위기와 텍스처', 그리고 '각 구역별 디자인 연출 방식'을 텍스트로 브리핑해 주세요.
(※ 주의: 이 단계에서는 코드를 작성하지 마십시오. 디자인 컨셉만 확정합니다.)



[STEP 2: 케이브덕 제약 사항 및 레이아웃 구조 설계]
1단계에서 확정한 디자인 테마를 '케이브덕(Caveduck)' 플랫폼 환경에 맞춰 구현하기 위한 기술적 설계를 진행합니다. 아래의 절대 규칙을 숙지하고, 어떻게 레이아웃을 짤 것인지 코드 구조 브리핑만 진행해 주세요.

[ 1. 케이브덕 플랫폼 절대 규칙 ]
- 인라인 스타일 ONLY: `<style>` 태그, `class` 속성, 미디어 쿼리(`@media`) 절대 사용 금지.
- 허용 태그: `<div>`, `<span>`, `<p>`, `<strong>`, `<br>`, `<em>`, `<a>`, `<b>`, `<i>`, `<hr>`, `<img>`
- 최상단 필수 코드: `<meta name="viewport" content="width=device-width, initial-scale=1.0">`

[ 2. 반응형 및 레이아웃 규칙 ]
- 뷰포트 대응: `padding`, `margin`, `font-size`는 `clamp()` 함수를 사용하여 유동적으로 조절 (예: `clamp(12px, 3vw, 24px)`).
- PC/모바일 반응형: 가로 폭에 따라 `display: flex; flex-wrap: wrap;`을 활용해 자동 줄바꿈 처리.
- 스크롤 제한: 가장 큰 메인 박스(Body/Container)에는 세로 스크롤(`overflow-y: scroll`) 절대 금지.

[ 3. 구역별 필수 디자인 조건 ]
- 프롤로그 훅(SNS, 채팅, 커뮤니티 글 등): 해당 플랫폼의 UI 특징(말풍선, 프로필 사진, 좋아요/댓글 버튼 아이콘 등)을 HTML 태그와 인라인 스타일로 그럴싸하게 흉내 내어 몰입감을 줄 것.
- 카드 섹션 (장소 및 NPC): 화면에 꽉 차게 디자인하고, 좌우 스크롤(`overflow-x: auto; display: flex;`) 기능을 반드시 적용할 것.
- 반투명 텍스트 박스: 카드 내부에 배경 이미지를 넣고, 그 위의 글씨가 잘 보이도록 텍스트 영역의 배경을 반투명하게 처리할 것 (예: `background: rgba(0, 0, 0, 0.6);`). 그림과 글씨가 모두 조화롭게 보여야 함.
- 그라데이션 연결: 사진과 내용이 상하로 나뉘는 구역(도입부, 세계관 등)은 위쪽 이미지 하단에 `linear-gradient`를 주어 아래 텍스트 영역 색상과 자연스럽게 섞이게 할 것.

(※ 주의: 이 단계에서도 전체 HTML 코드를 짜지 마십시오. 위 규칙을 어떻게 코드에 녹여낼지 기술적 접근 방식만 요약해 주세요.)


[STEP 3: 최종 HTML 코드 생성 (전체 출력)]
앞서 1단계에서 확정한 '테마/디자인'과 2단계에서 계획한 '케이브덕 인라인 레이아웃 구조'를 모두 결합하여 최종 HTML 코드를 생성할 차례입니다.
     
아래 [페이지 양식]의 모든 항목을 단 하나도 생략하거나 요약하지 말고, 캐릭터 설정에 맞춰 꽉꽉 채워 HTML 코드를 작성해 주세요. 대시보 형태의 요약본은 절대 금지합니다.
     
===================================
[ 페이지 양식 ] (아래 순서대로 HTML 구현)
     
< 0. 프롤로그 훅 (테마 맞춤형 인트로) >
- 플랫폼(에타, 인스타, 데이팅앱, 넷플릭스, 사내게시판 등)의 UI를 텍스트와 디자인으로 묘사한 가상의 글/댓글/대화내역.
- 캐릭터에 대한 소문이나 캐릭터 본인의 활동을 보여주어 유저의 흥미를 강하게 자극할 것.
     
< 1. 도입부 : 세계관이 드러나는 첫 만남 >
- 상단 이미지 + 하단 내용 (그라데이션으로 자연스럽게 연결)
(돈투텔 기법으로, 기존의 문체를 활용하여 캐릭터와 유저의 만남을 1000자로 구성해서 출력. )
(1. 감각의 입체화: 최소 2개 이상의 감각 동시 사용
2. Show, Don't Tell: 감정 직접 서술 금지
3. 모순 제시: 행동의 불일치로만 표현
4. 행동의 분절화: 시작-과정-결과 구조 유지
5. 유저 서술 금지
6. 의미심장한 침묵 활용
7. Anti-Looping:
   - 동일 단어 반복 금지
   - 동일 문장 구조 반복 금지
   - 동일 감각 조합 반복 금지
   - 매 시나리오마다 최소 1개 이상의 표현 방식 변경 필수 (환경 중심 / 행동 중심 / 감각 중심)
8. 금지어 필터: 상투적 표현 금지
9. 결말 훅: 선택 강요 금지, 여운 유지
10. 대사 제한: 3~4개 이하
11. 추임새 금지
12. 글자 수: 800~1000자
13. 수치 직접 표현 금지 → 문학적 변환)

< 2. 캐릭터 프로필 > (메인 캐릭터 카드: 화면 꽉 차는 이미지, 상단 60% 투명, 하단 40% 반투명 박스 내 세로 스크롤)
[ 이름 ]
이 름 : 
나이 / 성별 : 
외형 : (머리색, 헤어스타일, 눈매, 피부색, 체형, 의상 등 구체적으로)
직업 : 
성격 태그 : (#해시태그 3~5개)
호(♥) / 불호(X) : 
특기 / 취미 :
▶ (상세 특징1)(출력시엔 특징이름을 쓰기. 예시:사별남) : 
▶ (상세 특징2) : 
▶ 과거 : 
(※ 해당 시에만 작성: 능 력 명 / 상세 설명)
     
< 3. 캐릭터 시스템 > (설정이 있을 경우에만)
     
< 4. 세계관 (Worldbuilding) > (상단 이미지 + 하단 내용 구조. 만화나 게임의 프롤로그 소개처럼 세계관의 장르(현대/판타지/SF 등)와 분위기가 확연히 드러나도록 몰입감 있게 작성. 불필요하게 구구절절한 설정 나열을 피할 것.)
【 세계관 이름 】
▶ (어떤 세계관인지 장르적 색채가 뚜렷하게 드러나는 한 줄 요약)
▶ 세계의 모습 : (이 세계는 어떤 곳이며, 어떤 사람들이 살아가고 있는지 스토리텔링 형식으로 서술)
▶ 주요 세력 : (세계관 내에 조직, 세력, 종족 등이 존재할 경우, 설정에 맞춰 해당 집단의 특징과 역할을 자연스럽게 소개)(현대 세계관의 경우 생략가능)
▶ 세계의 명물 및 특징 : (이 세계에서 가장 유명한 장소, 문화, 물건, 혹은 일상적으로 통용되는 흥미로운 요소)
▶ 떠도는 소문/갈등 : (현재 세계관 내에서 벌어지는 주요 사건이나 이야기의 시작점이 되는 소문)
     
[ Locations ] (※ 반투명 텍스트 박스 + 꽉 찬 이미지 + 좌우 스크롤 카드 구조 필수)
(※ 주의: '장소의 전반적인 분위기'는 화면에 텍스트로 직접 출력하지 마십시오. 오직 해당 구역의 코드 테마(배경색, 텍스처, 폰트 스타일 등)를 구현하기 위한 시각적 디자인 지표로만 활용하십시오.)
▶ 핵심 구역 : 
   - (장소명) : (설명)
     
[ NPC ] (※ 반투명 텍스트 박스 + 꽉 찬 이미지 + 좌우 스크롤 카드 구조 필수)
(이름) / (역할 및 직업)
- 프로필 : 
- 성 향 : 
- 특이사항 : 
===================================
     
설명은 일절 하지 말고, 오직 완성된 반응형 단일 HTML/CSS(인라인) 코드만 하나의 코드 블록 안에 담아 출력하십시오.


---

# 부록 B — 케이브덕 영역별 호환성

# 케이브덕 HTML/CSS 호환성 규칙 — 사용자 제공 2026-10-08 확인표

이 파일은 2026-10-08 기준 사용자 제공 테스트 결과이다. 최신 플랫폼 동작을 별도로 검증한 결과가 아니며, 플랫폼 변경 가능성이 있다. 해당 결과가 이전 SKILL.md의 기술 규칙과 충돌하면 **이 파일을 우선**한다. 적용 영역은 각 스킬의 실제 출력 영역이다. `채팅`은 참고 자료이며 위젯/소개란에 채팅 전용 기능을 혼용하지 않는다.

## 전 영역 공통
- `<style>`, `<link>`, `<script>`, `<iframe>`, `<svg>`, `<canvas>`, `<form>`, `<input>`, `<button>` 사용 금지. 모든 CSS는 `style="..."` 인라인만 사용. `class`, CSS 선택자, `:hover`, `@media`, `@keyframes`, 웹 폰트 로딩 불가.
- 기본 허용 태그: `div span p br hr b strong i em` 및 HTML 주석. `h1`~`h6`는 위젯/소개란에서 불가. 제목은 `div`+font-size/font-weight. `table`, `progress`, `meter`도 위젯/소개란에서 불가; flex/grid 및 중첩 div 게이지로 대체.
- 인라인 CSS: color, background, padding, margin, border, border-radius, box-shadow/inset, outline, linear/radial/conic/repeating gradients, text-shadow, font-family/size/weight, letter-spacing, line-height, flex/gap, grid, absolute/sticky, transform, opacity, overflow, filter, backdrop-filter, clip-path, mix-blend-mode, mask-image, writing-mode, aspect-ratio, overflow-x/y, scroll-snap, scrollbar-color 등 사용자 확인표의 공통 허용 속성 사용 가능.
- `-webkit-backdrop-filter`, `-webkit-mask-image` 병기. 그라데이션 텍스트는 `background-clip:text;-webkit-background-clip:text;color:transparent` 조합. `filter:drop-shadow`와 `clip-path`는 바깥/안쪽 요소로 분리.
- 사이트 기존 애니메이션 `spin`, `pulse`, `ping`, `bounce`를 `animation:...`으로 호출할 수 있다고 사용자 보고. `display:inline-block`과 함께 사용하고, 없어져도 내용이 유지되는 장식에만 사용. 신규 키프레임 정의 금지.
- 모바일 우선: width:100%, max-width, box-sizing:border-box, overflow:hidden, 유연한 flex/grid, 텍스트 대비/줄바꿈, 과도한 고정폭 회피. `clamp()`는 위젯·소개란 가능, 채팅 내부는 불가.
- 시스템 폰트 폴백: `-apple-system,'Apple SD Gothic Neo','Malgun Gothic',sans-serif` 등. 외부 폰트 불가.
- 주석은 글자 수에 포함. 주석 내 `--` 구분선 피하고 간결하게 작성.

## 위젯 전용
- `<img>` 금지, `background:url()` 금지. **이미지 파일과 이미지 URL 일절 사용하지 않음.** 장식은 CSS gradient, repeating-linear-gradient 줄노트/사선, radial-gradient 점무늬, 격자, CSS 도형, 글자, div 게이지로 구현.
- 위젯 추가 허용 태그: `u s small mark sup sub code pre figure figcaption ul ol li details summary`. `details/summary`는 위젯에서만 접기 가능.
- `a` 링크 금지. `position:fixed` 가능하다고 보고되었지만 다른 UI를 가릴 수 있어 기본 금지/예외적 소형 장식만. `list-style-type` 가능.
- 필드 및 상태창이 이미지 없이도 완성되도록 설계하고 이미지 프롬프트나 `IMAGE_XX_URL` 슬롯을 위젯 HTML에 넣지 않는다.

## 소개란 전용 (캐릭터 페이지와 제작자 페이지 모두)
- 허용 태그는 공통 기본 태그와 `img`, `a`, 주석만. **`details`, `summary`, `ul`, `ol`, `li`, `u`, `s`, `small`, `mark`, `code`, `pre`, `figure`, `figcaption`, `table`, `h1`~`h6` 금지.** 목록은 div와 문자 기호로 구현.
- `<img src="IMAGE_01_URL">`와 `background:url(IMAGE_02_URL)` 허용. 모든 이미지 슬롯은 HTML 위치와 NAI 프롬프트 1:1 매칭. 배경과 NPC, 주인공 외형 태그 구별.
- `position:fixed` 금지. `position:sticky` 가능. `clamp()` 가능. `list-style-type` 사용 금지.
- 접이식 메뉴 불가: `details/summary` 대신 펼쳐진 카드, 독립적인 내부 스크롤 상자, 가로 스크롤로 구성. 가짜 탭/버튼이 실제로 작동한다고 주장하지 않는다.
- 기존 스킬의 `<meta name="viewport">` 예외 규칙은 사용자 허용표에 확인되지 않았으므로 **출력 HTML에서 `<meta>`를 제거**한다. 전체 문서/헤더가 아니라 붙여넣기 가능한 HTML 조각을 생성한다.
- `<a>`는 실제 링크가 주어질 때만. 외부 URL이나 이미지 URL을 임의로 만들지 않는다.

## 채팅 내부 (참고용, 이 3개 스킬의 출력 대상 아님)
- `<img>` 불가, `background:url()` 가능. `clamp()` 불가. `h1`~`h6`, `table`, `progress`, `meter`, `marquee`, `details` 등은 사용자 표에서 가능. 소개란/위젯에 이 규칙을 옮겨 쓰지 않는다.

## 출력 전 호환성 검사
1. 출력 영역 확인: 위젯인지 소개란인지 명시.
2. 모든 HTML 태그가 해당 영역의 허용 집합인지 확인.
3. style 블록/외부 폰트/클래스/JS/금지 CSS 존재 여부 확인.
4. 위젯에는 이미지가 없는지, 소개란에는 이미지 프롬프트와 URL 슬롯이 1:1인지 확인.
5. 모바일 텍스트, 스크롤, 대비, 중요 정보 노출 확인.
6. 미확인 기능을 '확인됨'이라고 단정하지 않는다.


---

# 부록 C — 독창성 및 HTML 구현 기술

# 독창적 HTML 연출 기술 라이브러리 — 참고작 비복제 원칙

## 목적
사용자가 제공한 외부 HTML은 **기술 작동 원리를 분석하는 학습 자료**이지, 재현할 템플릿·디자인 시안이 아니다. 외부 작품의 고유한 시각적 표현을 재사용하지 말고, 캐릭터/세계관/서사에서 독립적으로 출발한 결과물을 만든다. 기존 단계, 필수 내용, 이미지 프롬프트, 케이브덕 호환성 규칙은 모두 유지한다.

## 엄격한 비복제 규칙
- 참고작의 레이아웃 실루엣, 섹션 순서, 장식 위치, 대표 색 조합, 타이포그래피 구성, 텍스트 카피, 말풍선 좌표, 이미지 크롭, 특유의 장면 전환과 효과 조합을 복사하거나 사소하게 변형하지 않는다.
- '파스텔 웹툰형 / 블랙핑크 슬라이드 / 비밀기관 문서형 / RPG 도감형'을 고정 템플릿·스타일 프리셋·선택지로 두지 않는다. 사용자가 제공한 참고작의 고유 이름, 기관명, 캐릭터, 문구, 이미지 URL, SVG Base64 데이터, 좌표, 색상 값을 출력에 재사용하지 않는다.
- 같은 CSS 속성 자체는 일반 기술이므로 사용할 수 있지만, 여러 속성의 구체적 조합이 원본의 시각적 정체성을 재현한다면 설계를 폐기하고 다시 만든다.
- 제작 전에 레퍼런스를 치우고도 설명 가능한 독립적인 디자인 논리를 만든다. 결과물의 식별력 있는 특징이 참고작과 유사하면 색만 바꾸지 말고 정보 구조, 형태, 서사적 장치, 공간 구성, 이미지 연출까지 재설계한다.
- 특정 플랫폼/브랜드를 연상시키는 UI도 세계관에 적합한 독자적인 변형으로 만들고, 타 제작자의 원본 이미지·고유 로고·저작권 보호 요소를 가져오지 않는다.

## 기술 원리만 추출하는 목록 (예시이며 출력 형식을 고정하지 않음)
1. 레이어링: `position:relative` 부모 안에 `position:absolute` 텍스트·이미지·그라데이션을 겹쳐 배치. 이미지 위 정보는 명도 대비와 모바일 크롭을 검증.
2. 스크롤: `display:flex;overflow-x:auto;scroll-snap-type:x mandatory`와 자식의 `scroll-snap-align`으로 스크립트 없는 수평 탐색. 가로 스크롤은 원래 스킬의 장소/NPC 요구를 유지하되 카드 형태는 새롭게 설계.
3. 반응형: `max-width`, `width:100%`, `flex-wrap`, `clamp`, `aspect-ratio`, 지원이 검증된 경우 `container-type`과 `cqw` 사용. 지원 불확실하면 안전한 대안으로 전환.
4. 배경·정보 계층: 여러 gradient, 여백, 테두리, 배경 텍스처, `grid`/`flex` 등으로 중요도를 표현. 특정 참고작의 색/배치 패턴을 재현하지 않음.
5. 비정형 도형: `clip-path`, `mask-image`, `-webkit-mask-image`, outline, text-stroke 등으로 세계관에 맞는 독립 형태 제작. 효과 미지원 시 콘텐츠가 보이도록 폴백.
6. 데이터 시각화: 중첩 div로 정적 게이지·등급·관계 정보를 표현. 정적 시각화는 실시간으로 갱신되는 척하지 않음.
7. 움직임: 케이브덕 확인표에서 허용된 사이트 기본 애니메이션만 조건부로 사용. 외부 SVG 내부의 SMIL 애니메이션이나 Base64 SVG 마스크는 참고 코드에 존재하더라도 케이브덕 허용·동작이 확인되지 않았으므로 기본 출력 금지. 테스트 요청 시 별도 실험용으로만 제안하고, 실패해도 정보가 유지되는 정적 폴백 제공.
8. 동적 치환: 레퍼런스에 등장하는 임의의 `class` 기반 이름 치환은 사용하지 않는다. 사용자 제공 케이브덕 치환 구문이 검증되었을 때만 적용. 실제 기능이 없는 버튼/탭/화살표를 작동하는 것으로 설명하지 않음.

## 3단계별 적용
- STEP 1: 장르·세계관·관계·감정선·콘텐츠 우선순위를 분석해 독자적인 시각 콘셉트를 제안. 참고작 유형명을 콘셉트명으로 사용하지 않음. 왜 이 세계에서 이 UI가 존재하는지 설명.
- STEP 2: 선택한 기술의 목적, 레이어 구조, 반응형, 접근성, 케이브덕 허용 여부, 폴백을 설계. 기존 호환성 참고문서가 최우선.
- STEP 3: 기존 모든 필수 항목과 이미지 슬롯/NAI 프롬프트 매칭을 유지하며 독립적인 HTML 작성. 인라인 CSS만 사용. 참고작의 실제 이미지 주소, 복잡한 SVG 데이터, 특유의 장식/문구를 복사하지 않음.

## 출력 전 유사성 감사 (필수)
(1) 참고작과 큰 구조/시각적 실루엣이 닮았는가? (2) 색상·장식·글자·이미지 배치의 조합이 닮았는가? (3) 같은 장면 연출 순서를 답습했는가? (4) 고유 리소스를 재사용했는가? (5) 케이브덕 소개란 호환성을 지켰는가? 하나라도 문제가 있으면 다시 설계. 사용자가 '똑같이' 요청하지 않는 한 참고작 재현을 기본값으로 삼지 않는다.


---

# 부록 D — 5색 팔레트 설계

# 5색 팔레트 설계 규칙 — 사용자 제공 기준의 실무 적용

## 목적 및 우선순위
캐릭터 페이지의 STEP 1 테마·색채 브리핑, STEP 2 CSS 설계, STEP 3 최종 코드에 적용한다. 기존 원본의 내용 항목, 독창성 원칙, 케이브덕 영역별 HTML/CSS 호환성 규칙을 보존한다. 이 문서는 레퍼런스의 특정 팔레트를 재사용하기 위한 템플릿이 아니라 새로운 세계관에 맞는 색을 설계하는 **방법론**이다.

## 기본 1–기본 2–기본 3–강조–포인트
기본값은 60–30–10의 확장으로 이해하되 비율은 **근사적 가이드**다. 텍스트 색의 면적 비중과 배경 면적은 직접 비교하기 어려우므로 수치 총합을 강제하지 않는다.

| 슬롯 | 권장 역할 | 참고 비중 | 밝은 테마 출발점 |
|---|---|---|---|
| 기본 1 / Background | 최상위 배경·여백 | 40–50% | 고명도·극저채도, S 0–8%, B 95–100% |
| 기본 2 / Surface | 카드·보조 배경·구획 | 15–20% | 저채도, 기본 1보다 명도 5–15% 낮은 후보 |
| 기본 3 / Base Text·Neutral | 본문·아이콘·테두리·구조 | 15–20% (시각적 역할 기준) | 저명도·저채도, B 10–25%의 짙은 중성색 후보 |
| 강조 / Primary | 세계관 정체성·핵심 그래픽·주요 제목 | 10–15% | 중명도·중고채도 후보 |
| 포인트 / Point·CTA | 극소수의 주요 행동·알림·시선 유도 | 5% 미만 | 주변 대비가 강한 선명한 색 후보 |

**어두운 테마**는 명도 구조를 반전하거나 재구성한다. 기본 1을 밝게 고정하지 말고 배경·표면·텍스트의 기능과 대비를 유지한다. 포인트색은 무조건 가장 높은 채도가 아니라 **맥락상 가장 높은 시각적 우선순위**를 갖도록 한다. 페이지에 CTA가 없으면 포인트는 사건 단서·경고·핵심 문장에 제한적으로 쓴다.

## 색채 생성 절차
1. 캐릭터·장르·정서·시대·서사 소재에서 **강조색(Primary)**을 독립적으로 선택하고 HSB/HSV의 H, S, B와 HEX를 기록한다.
2. 강조색의 Hue를 느슨하게 공유하는 tinted neutral로 기본 1·2·3을 만든다. S 5–15%는 출발점일 뿐, 밝은 배경의 극저채도나 어두운 글자의 필요 대비에 따라 달리 설정한다. 순백·순검정도 의도와 대비가 맞으면 사용 가능하다.
3. 포인트색 후보는 유사색(Hue 차이 대략 30–60°), 보색·분할 보색(대략 150–180°), 또는 의도적인 단색 명도 대비로 탐색한다. 이는 강제 각도가 아니다. 색상환의 거리만으로 충분한 대비가 생긴다고 가정하지 않는다.
4. 색마다 역할, HEX, 적용 구역, 텍스트/배경 조합을 확정한다. 같은 캐릭터라도 밝은/어두운 버전은 각각 재설계한다.
5. **WCAG 명도 대비 검사:** 일반 본문 글자는 배경과 최소 4.5:1, 큰 글자는 최소 3:1을 목표로 한다. 핵심 UI 경계·아이콘 등 비텍스트 정보는 해당되는 경우 3:1을 목표로 한다. 포인트 버튼의 배경색과 글자색도 별도 검사한다. 대비율은 HSB의 B 차이나 흑백 필터만으로 판단하지 않고 sRGB 상대휘도 공식으로 계산한다.
6. 흑백 전환은 보조 시각 점검이다. 모든 5색이 서로 다른 명도 단계여야 할 필요는 없다. 실제로 중요한 것은 **서로 맞닿는 텍스트·표면·UI 요소 간 대비**다.
7. 포인트가 과다 사용되거나 카드·본문·강조색이 서로 경쟁하면 채도·면적·명도·간격을 재조정한다.

## 사용자 제공 예시 — 설명용이며 재사용 템플릿 아님
강조 H:220 S:80 B:90 → 기본 1 H:220 S:4 B:98, 기본 2 H:220 S:12 B:90, 기본 3 H:220 S:40 B:20. 포인트 후보 H:35 S:90 B:95. 이 값들은 배색 생성 원리를 보여주는 예시이며 **최종 캐릭터 페이지에 자동 복사하지 않는다**. 실제 조합은 HEX 변환 후 대비 검증하고, 미달하면 수정한다.

## 단계별 출력 규칙
- STEP 1: 기존 3–5색 팔레트 요청과 양립하도록 기본 5색을 우선 설계하고, 3색만 필요한 경우 기본 1 + 기본 3 + 강조 또는 기본 1 + 강조 + 포인트로 압축한다. 각 색의 **HEX / 슬롯 / 목적 / 예상 사용 영역 / 강조·포인트 관계**를 제시한다. 캐릭터의 독창적인 색채 근거를 설명한다.
- STEP 2: 각 슬롯을 실제 HTML 섹션과 인라인 CSS 속성에 매핑한다. 배경 위 텍스트, 이미지 오버레이 위 텍스트, 배지/버튼 위 텍스트의 대비를 검토한다. 별도 CSS 변수나 `<style>` 태그 사용은 해당 영역 호환성 문서가 허용하지 않으면 피한다.
- STEP 3: 최종 코드에 승인된 HEX를 일관되게 적용한다. 포인트 남용을 막고, 의미 있는 대비를 유지한다. 사용자가 요청하지 않으면 팔레트 이론을 코드 앞에 장황하게 출력하지 않는다.

## 독창성·호환성
외부 참고작의 구체적인 5색 조합을 모방하지 않는다. 레퍼런스에서 배울 것은 색의 **역할 분리, 생성 절차, 검증 방식**이다. 색채 설계가 성공하더라도 레이아웃·장식·이미지 배치가 참고작과 유사하면 독창성 검사에 따라 다시 설계한다. 케이브덕 HTML/CSS 허용 범위는 `caveduck_html_css_2026-10-08.md`가 우선한다.
