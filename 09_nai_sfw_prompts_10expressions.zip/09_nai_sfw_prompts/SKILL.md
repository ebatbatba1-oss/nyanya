---
name: 09_nai_sfw_prompts
description: Create 19 consistent English-tag NovelAI SFW image prompts with Korean translations, including 10 fixed expressions, for each character.
---

# NAI SFW illustration prompt creation

## When to use
Use when the user asks for step 9 of the CaveDuck workflow or explicitly asks for this deliverable.

## Required input
Use character, world, system, and prior-step data supplied in the current conversation. Preserve canonical names and established lore. If critical inputs are missing, ask one concise question; otherwise make modest, clearly compatible creative choices.

## Execution rules
Produce exactly **19 prompts per character** in this order:
1. ID portrait (1): face only, front-facing, simple white background, eye contact.
2. Main face portrait (1): face only, eye contact, character-appropriate mood.
3. **Fixed upper-body expressions (10)**: exactly one each, in this unchangeable order:
   01 무표정 / Neutral
   02 기쁨 / Happiness
   03 분노 / Anger
   04 슬픔 / Sadness
   05 놀람 / Surprise
   06 즐거움 / Amusement
   07 부끄러움 / Embarrassment
   08 사랑에 빠짐 / In Love
   09 절망 / Despair
   10 후회 / Regret
4. Named cowboy-shot scenarios (5).
5. Named cowboy-shot dates (2).

The ten expression **categories, count and order are mandatory**, never chosen or replaced based on character personality. Adapt only how each emotion appears through eye shape, mouth, gesture, posture, gaze, lighting and context. Differentiate happiness (pleasure/contentment) from amusement (laughter/playfulness), sadness (sorrow) from despair (loss of hope), and regret (remorse over a choice) from general sadness. Maintain consistent canonical hair, eyes, skin, body and species traits across all prompts.

Each prompt: English comma-separated tags followed immediately by Korean tag translation. Preserve the source's seven-part ordering, indoor/outdoor/scenery and time tags, no character names in prompts, consistent weighting, no parentheses, no extraneous commentary. Do not describe invisible details in close crops. Date images show the character alone; a viewer hand may appear only if direction is unambiguous. For multiple characters, process separately in batches of one or two.

## Source fidelity
The user-provided step 9 specification is stored in `references/original_user_spec.md`, with the expression section updated to ten fixed categories. Follow all detailed formatting and content constraints except where overridden by platform safety requirements.

## Output medium (mandatory)
Write TEXT PROMPTS ONLY for NovelAI. Never generate images. Deliver copy-ready English tags and Korean translations. Category counts: **1+1+10+5+2=19**.
