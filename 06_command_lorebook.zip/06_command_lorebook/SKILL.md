---
name: 06-command-lorebook
description: 명령어 로어북 제작 — Cave Duck reusable workflow
---

# 명령어 로어북 제작

Generate Cave Duck functional command lorebook entries based on the current character/world and user-selected functions. Never confuse instructions to generate HTML with literal output-rule text.

Format: `1.키워드: !한국어|!english|!日本語|!繁體中文|!简体中文|!português|!español|!deutsch|!français<br>` followed by `[명령어] ([AI 실행 지침]: ...)<br>` and `<br>` between entries. Supply sensible translations, preserve aliases specified by user, and use roughly 300–400 Korean characters for normal commands unless a command explicitly requires longer. Do not invent current plot events or NPC memories; reference established context.

Core commands:
- !관계|!relation|!relación: first meeting = NPC's first impression; otherwise mutual/one-sided recognition with subject, relationship depth, first meeting and feelings. For long relationships include at least two memorable episodes, their effects and desired future. In execution instruction request 1500+ words, fiction prose, no OOC.
- !완화|!relax|!calm: soften possessiveness/control into partnership and support, guilt into growth, dependency into mutual encouragement, worship into trust, despair into hope; avoid hierarchy and clichés, preserve character individuality.
- !요약|!summary|!recap: append at bottom exactly five turn summaries each beginning/process/result in one sentence each, then core event, relationship before→after, emotion before→after. If fewer than five turns exist, only summarize available turns.
- !힌트|!hint|!guide|!pista: two contrasting Type A / Type B narrative options, concise OOC advice.
- !섹스스킵: only during established adult intimate scenes, progress via non-graphic fade-to-black time skips; 4–5 timestamped events, locations, emotional tone and NPC comments. Do not generate explicit anatomical sexual descriptions or nonconsensual sexual acts.
- !유저: pause RP and generate fitting player persona of 1000+ Korean characters: name, age (adult), gender, job, species if relevant, height/weight/body, hair/eyes/skin/clothes, MBTI, 5 positive and 2 negative traits, abilities, residence, background, NPC ties, reputation, intimate preferences stated non-graphically, secrets. Append at bottom.
- !톡|!talk|!messenger: only previously met NPCs, messenger screen.
- !SNS|!gram|!twitter: exactly four feeds with handle, 20+ character post, hashtags, engagement counts, comments; choose account types suitable for setting rather than always students.
- !커뮤|!community|!dc: anonymous community board with colloquial posts and reactions.
- Genre extensions: noir !조사/!scan (information vs leverage), !담배/!smoke (regret); fantasy !마법/!magic (protect vs threaten), !반지/!ring (family pride/trauma); school !폰/!phone (phone history without fabricating unlawful surveillance), !일기/!diary (private feelings, respecting narrative access).

For messenger/SNS/community commands, WRITE THIS AS A LITERAL OUTPUT INSTRUCTION in the lorebook, not finished HTML: `[출력 규칙]: HTML(각 항목은 br태그로 구분)(단일코드블럭(내용)으로 감쌈/공백줄없이모든코드붙여서/외부이미지호출금지/CSS는 인라인으로만 사용/배경은어두운색사용)`; also preserve user's specialized single-line instruction verbatim when provided: `HTML규칙:인라인스타일/속성=''(홑따옴표)必,絶対(\n)X=,처음~끝한줄=Minified.h태그&코드블록()금지.(규칙엄수)`. These two source variants conflict about code blocks: when both apply, explicitly show both as user-provided variants and ask which is authoritative rather than silently merging.
