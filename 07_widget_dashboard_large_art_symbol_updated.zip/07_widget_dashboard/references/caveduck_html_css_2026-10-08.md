# 케이브덕 HTML/CSS 호환성 규칙 — 사용자 제공 2026-10-08 확인표

이 파일은 2026-10-08 기준 사용자 제공 테스트 결과이다. 최신 플랫폼 동작을 별도로 검증한 결과가 아니며, 플랫폼 변경 가능성이 있다. 해당 결과가 이전 SKILL.md의 기술 규칙과 충돌하면 **이 파일을 우선**한다. 적용 영역은 각 스킬의 실제 출력 영역이다. `채팅`은 참고 자료이며 위젯/소개란에 채팅 전용 기능을 혼용하지 않는다.

## 전 영역 공통
- `<style>`, `<link>`, `<script>`, `<iframe>`, `<svg>`, `<canvas>`, `<form>`, `<input>`, `<button>` 사용 금지. 모든 CSS는 `style="..."` 인라인만 사용. `class`, CSS 선택자, `:hover`, `@media`, `@keyframes`, 웹 폰트 로딩 불가.
- 기본 허용 태그: `div span p br hr b strong i em` 및 HTML 주석. `h1`~`h6`는 위젯/소개란에서 불가. 제목은 `div`+font-size/font-weight. `table`, `progress`, `meter`도 위젯/소개란에서 불가; flex/grid 및 중첩 div 게이지로 대체.
- 인라인 CSS: color, background, padding, margin, border, border-radius, box-shadow/inset, outline, linear/radial/conic/repeating gradients, text-shadow, font-family/size/weight, letter-spacing, line-height, flex/gap, grid, absolute/sticky, transform, opacity, overflow, filter, backdrop-filter, clip-path, mix-blend-mode, mask-image, writing-mode, aspect-ratio, overflow-x/y, scroll-snap, scrollbar-color 등 사용자 확인표의 공통 허용 속성 사용 가능.
- `-webkit-backdrop-filter`, `-webkit-mask-image` 병기. 그라데이션 텍스트는 `background-clip:text;-webkit-background-clip:text;color:transparent` 조합. `filter:drop-shadow`와 `clip-path`는 바깥/안쪽 요소로 분리.
- 사이트 기존 애니메이션 `spin`, `pulse`, `ping`, `bounce`를 `animation:...`으로 호출할 수 있다고 사용자 보고. `display:inline-block`과 함께 사용하고, 없어져도 내용이 유지되는 장식에만 사용. 신규 키프레임 정의 금지.
- 모바일 우선: width:100%, max-width, box-sizing:border-box, overflow:hidden, 유연한 flex/grid, 텍스트 대비/줄바꿈, 과도한 고정폭 회피. `clamp()`는 위젯·소개란 가능, 채팅 내부는 불가.
- 시스템 폰트 폴백: `-apple-system,'Apple SD Gothic Neo','Malgun Gothic',sans-serif` 등. 외부 폰트 불가.
- 주석은 글자 수에 포함. 주석 내 `--` 구분선 피하고 간결하게 작성.

## 위젯 전용
- `<img>` 금지, `background:url()` 금지. **이미지 파일과 이미지 URL 일절 사용하지 않음.** 장식은 CSS gradient, repeating-linear-gradient 줄노트/사선, radial-gradient 점무늬, 격자, CSS 도형, 글자, div 게이지로 구현.
- 위젯 추가 허용 태그: `u s small mark sup sub code pre figure figcaption ul ol li details summary`. `details/summary`는 위젯에서만 접기 가능.
- `a` 링크 금지. `position:fixed` 가능하다고 보고되었지만 다른 UI를 가릴 수 있어 기본 금지/예외적 소형 장식만. `list-style-type` 가능.
- 필드 및 상태창이 이미지 없이도 완성되도록 설계하고 이미지 프롬프트나 `IMAGE_XX_URL` 슬롯을 위젯 HTML에 넣지 않는다.

## 소개란 전용 (캐릭터 페이지와 제작자 페이지 모두)
- 허용 태그는 공통 기본 태그와 `img`, `a`, 주석만. **`details`, `summary`, `ul`, `ol`, `li`, `u`, `s`, `small`, `mark`, `code`, `pre`, `figure`, `figcaption`, `table`, `h1`~`h6` 금지.** 목록은 div와 문자 기호로 구현.
- `<img src="IMAGE_01_URL">`와 `background:url(IMAGE_02_URL)` 허용. 모든 이미지 슬롯은 HTML 위치와 NAI 프롬프트 1:1 매칭. 배경과 NPC, 주인공 외형 태그 구별.
- `position:fixed` 금지. `position:sticky` 가능. `clamp()` 가능. `list-style-type` 사용 금지.
- 접이식 메뉴 불가: `details/summary` 대신 펼쳐진 카드, 독립적인 내부 스크롤 상자, 가로 스크롤로 구성. 가짜 탭/버튼이 실제로 작동한다고 주장하지 않는다.
- 기존 스킬의 `<meta name="viewport">` 예외 규칙은 사용자 허용표에 확인되지 않았으므로 **출력 HTML에서 `<meta>`를 제거**한다. 전체 문서/헤더가 아니라 붙여넣기 가능한 HTML 조각을 생성한다.
- `<a>`는 실제 링크가 주어질 때만. 외부 URL이나 이미지 URL을 임의로 만들지 않는다.

## 채팅 내부 (참고용, 이 3개 스킬의 출력 대상 아님)
- `<img>` 불가, `background:url()` 가능. `clamp()` 불가. `h1`~`h6`, `table`, `progress`, `meter`, `marquee`, `details` 등은 사용자 표에서 가능. 소개란/위젯에 이 규칙을 옮겨 쓰지 않는다.

## 출력 전 호환성 검사
1. 출력 영역 확인: 위젯인지 소개란인지 명시.
2. 모든 HTML 태그가 해당 영역의 허용 집합인지 확인.
3. style 블록/외부 폰트/클래스/JS/금지 CSS 존재 여부 확인.
4. 위젯에는 이미지가 없는지, 소개란에는 이미지 프롬프트와 URL 슬롯이 1:1인지 확인.
5. 모바일 텍스트, 스크롤, 대비, 중요 정보 노출 확인.
6. 미확인 기능을 '확인됨'이라고 단정하지 않는다.
