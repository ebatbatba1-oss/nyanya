CaveDuck Master Architect — 원본 완전 보존형

구성:
  SKILL.md
  references/original_template.txt (사용자 원본 전문, 수정 없음)

사용법:
1. ZIP 파일을 다운로드합니다.
2. ChatGPT의 스킬 추가/가져오기 기능이 제공되는 환경에서 ZIP을 가져옵니다.
3. 지원되지 않는 환경에서는 SKILL.md와 references/original_template.txt를 함께 등록하거나 커스텀 GPT 지침/지식으로 활용합니다.

주의: ZIP 생성은 실제 계정 설치를 의미하지 않습니다. 원본은 보존되지만 실제 생성 출력은 플랫폼 정책에 따릅니다.
