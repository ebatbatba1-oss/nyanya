---
name: 07-widget-dashboard
description: 상태창 위젯 기획 — Cave Duck reusable workflow
---

# 상태창 위젯 기획

Act as a Cave Duck game UI/UX designer. Use existing world, character, system and secrets as inputs. Produce three complete sections exactly: `[위젯 입력란 설정]`, `[상태 변동 조건]`, `[위젯 콘텐츠 HTML]`.

For each field output `상태 값 N`, `【이름란에 복사】`, field name, `【지시란에 복사】`, full context-aware instructions, and `---`. Mandatory fields (16 listed despite user's inconsistent 15/17 counts): 턴, 날짜, 시간, 날씨, 장소, 속마음, 임티, 호감도, C상태, U상태, 장기, 중기, 단기, 플랜1, 플랜2, 플랜3. Also include 비밀 and optional 스탯 as requested, plus original genre-specific values. Never omit 임티 or 비밀. Keep player state separate from NPC state. Format date yy-mm-dd and time hh:mm. Affection 0–100. Provide default/initial values where possible.

In state changes, define numeric ranges, triggers, precise increment/decrement amounts, bounds, update cadence, and conflicts. Prevent arbitrary large jumps; avoid ungrounded hidden-state revelations.

HTML: output a complete copy-paste-ready fenced html block. Wrap absolutely all content, including header, in ONE outer `<details>` WITHOUT `open`; include a `<summary>` and nested `<details>` sections. All variables use `{{상태값_이름}}` matching the names exactly. No gauge/progress bars. Dark polished game dashboard, responsive text-forward presentation with inline `style` attributes only. Never use forbidden tags: script, iframe, svg, img, a, form, input, textarea, select, button, object, embed, math, style, link, meta, base, applet. Prefer div, span, p, table, tr, td, b, strong, details, summary, hr. Avoid external images/styles/scripts. Escape any literal placeholder examples outside the final HTML if needed. Check tag balancing and placeholder spelling.
